import java.util.*;
class STUDENT{
    Scanner sc = new Scanner(System.in);
    String sname;
    int [] marks_array;
    double total=0;
    double avg=0;

    //default constructor
    STUDENT(){
        this.sname = "unknown";
    }



    //parameterized constructor:
    STUDENT(String sname, int n){
        this.sname = sname;
        marks_array = new int[n];
        System.out.println("Enter marks: ");
        for (int i = 0; i<n; i++)
        {
            marks_array[i] = sc.nextInt();
        }

    }

    void assign(String sname, int n)
    {
        marks_array = new int[n];
        this.sname = sname;
        System.out.println("Enter marks: ");
        for(int i=0; i<n; i++)
        {
            marks_array[i] = sc.nextInt();
        }
    }

    void display()
    {
        System.out.println("Name :"+sname);
        System.out.println("Total marks:"+ total);
        System.out.println("Average marks: "+avg);

        for (int i=0; i<marks_array.length; i++)
        {
            System.out.println("Marks of subject "+(i+1)+" is: "+marks_array[i]);

        }
    }

    void compute()
    {total = 0;
        for (int i = 0; i<marks_array.length; i++)
        {
            total += marks_array[i];
        }
        avg = total/marks_array.length;
    }

}

public class StudentDetails {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number of subjects: ");
        int n = sc.nextInt();
        sc.nextLine();

        //Student 1:
        {
            System.out.println("Enter Student name: ");
            String sname = sc.nextLine();
            STUDENT s1 = new STUDENT();
            s1.assign(sname, n);
            s1.compute();
            System.out.println("Displaying details: ");
            s1.display();
        }

        //Student 2:
        {
            System.out.println("Enter Student name: ");
            String sname = sc.nextLine();
            STUDENT s2 = new STUDENT(sname, n);
            s2.compute();
            System.out.println("Displaying details: ");
            s2.display();
        }




    }
}
