import java.util.*;
class BankAccount{
    Random random = new Random();
    Scanner sc = new Scanner(System.in);
    String name;
    int accountNumber;
    String typeOfAccount;
    double bal;
    static double interestRate = 3.5;
    double randomValue = 50000.00+(random.nextDouble()*(100000.00-50000.00));

    BankAccount() {
        this.name = "Unknown";
        this.accountNumber = 0;
        this.typeOfAccount = "Savings";
        this.bal = 50000;
    }


    BankAccount(String name, int accountNumber, String typeOfAccount){
        this.name = name;
        this.accountNumber = accountNumber;
        this.typeOfAccount = typeOfAccount;
        bal = randomValue;
    }

    void showBalance(){
        System.out.println("Balance is: "+bal);
    }

    void deposit(){
        double depositAmount;
        System.out.println("Enter amount to deposit");
        depositAmount = sc.nextDouble();
        bal+=depositAmount;
        showBalance();
    }

    void withdraw(){
        double withdrawAmount;
        System.out.println("Enter amount to withdraw: ");
        withdrawAmount = sc.nextDouble();

        if(withdrawAmount>bal)
            System.out.println("Account Balance Low! Cant withdraw, Kindly enter less amount");
        else {
            System.out.println(withdrawAmount + "Withdrawn");
            bal -= withdrawAmount;
        }
        showBalance();
    }

    void display(){
        System.out.println("Details are as follows: ");
        System.out.println();
        System.out.println("Name: "+name);
        System.out.println("Account number: "+accountNumber);
        System.out.println("Type of account: "+typeOfAccount);
        System.out.println("Balance in rupees: "+bal);
        System.out.println("Rate of interest: "+interestRate);
    }

    static void displayROI(){
        System.out.println("Rate of interest: "+interestRate+"% ");
    }



}


public class Bank {
    public static void main(String[] args) {
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of account holders: ");
        n = sc.nextInt();
        sc.nextLine();
        BankAccount [] accountHolder = new BankAccount[n];
        for(int i=0; i<n; i++)
        {
            System.out.println("Enter name: ");
            String name = sc.nextLine();
            System.out.println("Enter account number: ");
            int accountNumber = sc.nextInt();
            sc.nextLine();
            System.out.println("Enter Type of account: ");
            String typeofAccount = sc.nextLine();
            accountHolder[i] = new BankAccount(name,accountNumber,typeofAccount);
            accountHolder[i].showBalance();
            accountHolder[i].deposit();
            accountHolder[i].withdraw();
        }

        for (int i=0; i<n; i++)
        {
            accountHolder[i].display();
        }
        System.out.println();
        BankAccount.displayROI();

    }
}