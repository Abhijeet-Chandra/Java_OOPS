import java.util.*;
class Counter{
    private static int countvar;

    Counter(){
        countvar++;
    }
    static void showCount(){
        System.out.println("Count is: "+countvar);
    }
}

public class CounterMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean input=true;
        Counter [] objArray = new Counter[1000];
        int i=0;
        while(input)
        {
            System.out.println("Enter Y for creating object and N for exiting program: ");
            String choice = sc.next();

            if(choice.equalsIgnoreCase("Y"))
            {
                objArray[i] = new Counter();
            }
            else if (choice.equalsIgnoreCase("N")) {
                System.out.println("Showing count....");
                Counter.showCount();
                input = false;
            }

            else {
                System.out.println("Enter Y/N only");
                continue;
            }
            i++;
        }


    }
}
