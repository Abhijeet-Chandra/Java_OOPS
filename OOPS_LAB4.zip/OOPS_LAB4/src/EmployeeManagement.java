import javax.rmi.ssl.SslRMIClientSocketFactory;
import java.util.*;

class EMPLOYEE{
    Scanner sc = new Scanner(System.in);
    String Ename;
    int Eid;
    double Basic;
    double DA;
    double Gross_sal;
    double Net_sal;

    EMPLOYEE(){
        System.out.println("Accessing details: ");
    }

    int n;
    EMPLOYEE(int n){
        this.n = n;
    }

    void read(){
        System.out.println("Enter name of employee: ");
        Ename = sc.nextLine();

        System.out.println("Enter Employee id: ");
        Eid = sc.nextInt();

        System.out.println("Enter Basic: ");
        Basic = sc.nextDouble();
    }
    void compute(){
        DA = 0.52*Basic;
        Gross_sal = Basic+DA;
        Net_sal = Gross_sal - 0.3*Gross_sal;

    }

    void display(){

            System.out.println("Name: "+Ename);
            System.out.println("Basic: "+Basic);
            System.out.println("DA: "+DA);
            System.out.println("Gross sal: "+Gross_sal);
            System.out.println("Net sal: "+Net_sal);
            System.out.println();

    }
}


public class EmployeeManagement {
    public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of employees: ");
        int n = sc.nextInt();
        EMPLOYEE [] empArr = new EMPLOYEE[n];

        for (int  i=0; i<n; i++)
        {
            empArr[i] = new EMPLOYEE(n);
            empArr[i].read();
            empArr[i].compute();
        }

        for (int i = 0; i<n; i++)
        {
            empArr[i].display();
        }

    }
}
