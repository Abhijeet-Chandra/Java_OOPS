//Write a Java program to display non principal diagonal elements and find their sum.
//[Hint: Non Principal diagonal: The diagonal of a diagonal matrix from the top
//right to the bottom left corner is called non principal diagonal.]

import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter no of rows: ");
        int m = sc.nextInt();

        System.out.println("Enter no of cols: ");
        int n = sc.nextInt();

        int [][] arr = new int[m][n];

        System.out.println("Enter the elements of array: ");
        for (int i =0; i<m; i++)
        {
            for (int j =0; j<n; j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }


        int sum = 0;
        System.out.println("Array is: ");
        for (int i =0; i<m; i++)
        {
            for (int j =0; j<n; j++)
            {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }

        for (int i=0; i<m; i++)
        {
            System.out.print(arr[i][n-i-1]+", ");
            sum = sum + arr[i][n-i-1];
        }

        System.out.println("Sum of secondary diagonals is: "+sum);
    }
}